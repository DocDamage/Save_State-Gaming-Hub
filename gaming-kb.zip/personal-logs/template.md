
# Personal Gaming Log

## Game
## Session Length
## What Improved
## What Felt Bad
## Decision for Next Session
