# Single Source of Truth

This repository merges v2 (foundational knowledge) and v3 (personal operator layer)
into one authoritative knowledge base for a single-user gaming assistant.
