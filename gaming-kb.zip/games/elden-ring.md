
# Elden Ring

## Genre
Action RPG

## Core Loop
Explore → Combat → Loot → Level Up → Harder Content

## Key Mechanics
- Stamina-based combat
- Open-world exploration
- Boss-driven progression

## Player Appeal
- High difficulty
- Exploration freedom
- Build diversity
