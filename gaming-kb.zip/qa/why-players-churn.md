
# Why Players Churn

## Common Causes
- Excessive grind
- Poor matchmaking
- Unbalanced meta
- Monetization pressure

## Indicators
- Drop in session length
- Reduced login frequency

## Mitigation Strategies
- Fair progression pacing
- Transparent balance updates
