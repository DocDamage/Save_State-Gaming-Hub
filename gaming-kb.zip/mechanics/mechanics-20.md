
# Mechanics Topic 20

## Overview
Structured factual explanation.

## Key Points
- Definition
- Systems involved
- Design considerations
