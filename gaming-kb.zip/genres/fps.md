
# First-Person Shooters (FPS)

## Definition
FPS games present gameplay through a first-person camera, emphasizing ranged combat, precision aiming, and spatial awareness.

## Core Mechanics
- Hitscan vs projectile weapons
- Recoil, spread, and bloom systems
- Health models (regen, armor, shields)
- Movement tech (strafe, slide, bunny hop)

## Skill Expression
- Mechanical aim
- Reaction time
- Map control
- Audio awareness

## Subgenres
| Subgenre | Focus |
|--------|-------|
| Arena | Speed, equal loadouts |
| Tactical | Positioning, realism |
| Hero | Abilities, roles |
