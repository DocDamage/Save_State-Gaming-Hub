
# Terminology Topic 2

## Overview
Structured factual explanation.

## Key Points
- Definition
- Systems involved
- Design considerations
