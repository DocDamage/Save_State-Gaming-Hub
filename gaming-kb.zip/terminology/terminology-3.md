
# Terminology Topic 3

## Overview
Structured factual explanation.

## Key Points
- Definition
- Systems involved
- Design considerations
