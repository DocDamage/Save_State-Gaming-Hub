
# Gaming Knowledge Base v2

This repository is a high-density, LLM-optimized gaming knowledge base designed for:
- Retrieval-Augmented Generation (RAG)
- Game recommendation systems
- Gaming chatbots (casual, competitive, and dev-focused)

## Design Principles
- Modular Markdown files
- 300–700 tokens per file
- One concept per section
- No opinions unless labeled
- Optimized for chunking by headers

## Intended Use
- Vector database ingestion
- Semantic search
- Tool-augmented LLMs
