
# Weekly Meta Summary Logic

## Inputs
- Patch notes
- Win-rate shifts
- Pick/ban data
- Player sentiment

## Output
- Dominant strategies
- Overperformers
- Underperformers
- Safe picks

## Constraint
No invented statistics.
