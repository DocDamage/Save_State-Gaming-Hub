
# Time–Value Scoring Framework

## Purpose
Estimate whether a game is worth the player's limited time.

## Dimensions
- Learning Curve
- Skill Ceiling
- Grind Intensity
- Replay Value
- Update Longevity

## Scoring (1–5)
Final Score = (Ceiling + Replay + Longevity) - (Grind + Friction)

## Interpretation
- 7+ → Strong long-term investment
- 4–6 → Conditional
- ≤3 → Likely time sink
