
# Burnout and Tilt Detection

## Indicators
- Increased session length with lower enjoyment
- Repeated queueing after losses
- Declining performance metrics

## Bot Actions
- Recommend breaks
- Suggest mode changes
- Propose quitting the game entirely

## Rule
Fun loss > Skill gain = stop
