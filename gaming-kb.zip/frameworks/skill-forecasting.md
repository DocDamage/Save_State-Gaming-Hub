
# Skill Progression Forecasting

## Inputs
- Weekly playtime
- Current rank
- Learning rate
- Mechanical vs strategic skill split

## Output
- Estimated rank plateau
- Time to next milestone
- Diminishing returns warning

## Use Case
Decide whether pushing ranked is worth it.
