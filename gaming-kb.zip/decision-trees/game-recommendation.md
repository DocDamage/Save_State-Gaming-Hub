
# Game Recommendation Decision Tree

## Step 1: Time Commitment
- <5 hrs/week → casual-friendly games
- 5–15 hrs/week → progression-based games
- 15+ hrs/week → competitive or mastery-heavy games

## Step 2: Skill Preference
- Mechanical → FPS, action
- Strategic → RTS, turn-based
- Systems → RPG, sandbox

## Step 3: Friction Tolerance
- Low → forgiving mechanics
- Medium → learning curves
- High → punishing difficulty
